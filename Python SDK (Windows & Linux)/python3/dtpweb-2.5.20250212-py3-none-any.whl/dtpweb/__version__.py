# dtpweb python interface

__title__ = 'dtpweb'
__version__ = '2.5.2024.813'
__author__ = 'DothanTech'
__author_email__ = 'hudianxing@dothantech.com'
__copyright__ = 'Copyright 2024 DothanTech'
